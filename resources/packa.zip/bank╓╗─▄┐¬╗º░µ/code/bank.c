//定义key并初始化
#include "bank.h"

const int key1 = 0x01234567;
const int key2 = 0x12345678;
